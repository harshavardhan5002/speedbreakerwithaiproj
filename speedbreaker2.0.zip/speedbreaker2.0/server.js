const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.static('public'));

// Set your COM port (e.g., COM11 for Windows)
const portName = 'COM11';

// Initialize SerialPort
const serialPort = new SerialPort({ path: portName, baudRate: 9600 });
const parser = serialPort.pipe(new ReadlineParser({ delimiter: '\n' }));

serialPort.on('open', () => {
    console.log(`✅ Connected to Arduino on ${portName}`);
});

parser.on('data', (line) => {
    console.log("Received from Arduino:", line.trim());

    try {
        const sensorData = JSON.parse(line.trim());

        // Broadcast the received sensor data to all connected clients
        io.emit('sensorData', sensorData);
    } catch (error) {
        console.error("⚠️ Error parsing serial data:", error.message);
    }
});

serialPort.on('error', (err) => {
    console.error("⚠️ Serial Port Error:", err.message);
});

server.listen(3000, () => {
    console.log("🚀 Server is running on port 3000...");
});
