import tensorflow as tf
import os
import glob
import xml.etree.ElementTree as ET
from object_detection.utils import dataset_util

ANNOTATIONS_DIR = "C:/Users/harsh/OneDrive/Desktop/pics for training/annotations.csv"
TFRECORD_OUTPUT = "C:/Users/harsh/OneDrive/Desktop/pics for training/dataset.tfrecord"

LABEL_MAP = {"speedbreaker": 1, "pothole": 2}  # Assign class IDs

def create_tf_example(xml_file):
    tree = ET.parse(xml_file)
    root = tree.getroot()

    filename = root.find("filename").text.encode("utf8")
    width = int(root.find("size/width").text)
    height = int(root.find("size/height").text)

    xmins, xmaxs, ymins, ymaxs, classes, classes_text = [], [], [], [], [], []

    for obj in root.findall("object"):
        label = obj.find("name").text
        bbox = obj.find("bndbox")
        xmins.append(float(bbox.find("xmin").text) / width)
        xmaxs.append(float(bbox.find("xmax").text) / width)
        ymins.append(float(bbox.find("ymin").text) / height)
        ymaxs.append(float(bbox.find("ymax").text) / height)
        classes.append(LABEL_MAP[label])
        classes_text.append(label.encode("utf8"))

    tf_example = tf.train.Example(features=tf.train.Features(feature={
        "image/height": dataset_util.int64_feature(height),
        "image/width": dataset_util.int64_feature(width),
        "image/filename": dataset_util.bytes_feature(filename),
        "image/object/bbox/xmin": dataset_util.float_list_feature(xmins),
        "image/object/bbox/ymin": dataset_util.float_list_feature(ymins),
        "image/object/bbox/xmax": dataset_util.float_list_feature(xmaxs),
        "image/object/bbox/ymax": dataset_util.float_list_feature(ymaxs),
        "image/object/class/text": dataset_util.bytes_list_feature(classes_text),
        "image/object/class/label": dataset_util.int64_list_feature(classes),
    }))

    return tf_example

with tf.io.TFRecordWriter(TFRECORD_OUTPUT) as writer:
    for xml_file in glob.glob(os.path.join(ANNOTATIONS_DIR, "*.xml")):
        tf_example = create_tf_example(xml_file)
        writer.write(tf_example.SerializeToString())

print("✅ TFRecord dataset created successfully.")
