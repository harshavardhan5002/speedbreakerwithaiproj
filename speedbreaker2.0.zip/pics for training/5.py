import os
import json
import glob
import cv2
import numpy as np
import shutil
import random

# Paths - MODIFY BASED ON YOUR SETUP
labelme_folder = r"C:\Users\harsh\OneDrive\Desktop\pics for training"  # Folder with JSON files
yolo_output_folder = r"C:\Users\harsh\OneDrive\Desktop\yolo_dataset"  # New YOLO dataset location

# ✅ STEP 1: Create Dataset Folders
for folder in ["images/train", "images/val", "labels/train", "labels/val"]:
    os.makedirs(os.path.join(yolo_output_folder, folder), exist_ok=True)

# ✅ STEP 2: Define Class Names (Must Match JSON Labels)
class_names = ["spd", "pot"]  # "spd" = Speed bump, "pot" = Pothole

# ✅ STEP 3: Convert JSON to YOLO Format
json_files = glob.glob(os.path.join(labelme_folder, "*.json"))
random.shuffle(json_files)  # Shuffle dataset for train/val split
split_index = int(len(json_files) * 0.8)  # 80% Train, 20% Val

for idx, json_file in enumerate(json_files):
    with open(json_file, "r") as f:
        data = json.load(f)

    image_path = os.path.join(labelme_folder, data["imagePath"])
    if not os.path.exists(image_path):
        print(f"❌ Image missing: {image_path}, skipping...")
        continue

    image = cv2.imread(image_path)
    h, w, _ = image.shape

    # ✅ Assign image to train or val
    dataset_type = "train" if idx < split_index else "val"

    # ✅ Save Image
    output_image_path = os.path.join(yolo_output_folder, f"images/{dataset_type}", os.path.basename(image_path))
    cv2.imwrite(output_image_path, image)

    # ✅ Convert Annotations to YOLO Format
    yolo_txt_path = os.path.join(yolo_output_folder, f"labels/{dataset_type}", os.path.splitext(os.path.basename(image_path))[0] + ".txt")

    with open(yolo_txt_path, "w") as yolo_file:
        for shape in data["shapes"]:
            label = shape["label"]
            if label not in class_names:
                print(f"⚠️ Skipping unknown label: {label}")
                continue

            class_id = class_names.index(label)  # Get class index
            points = np.array(shape["points"])
            xmin, ymin = points.min(axis=0)
            xmax, ymax = points.max(axis=0)

            if xmax == xmin or ymax == ymin:
                print(f"⚠️ Skipping empty bounding box in {json_file}")
                continue

            # Convert to YOLO format
            x_center = (xmin + xmax) / (2 * w)
            y_center = (ymin + ymax) / (2 * h)
            bbox_width = (xmax - xmin) / w
            bbox_height = (ymax - ymin) / h

            yolo_file.write(f"{class_id} {x_center} {y_center} {bbox_width} {bbox_height}\n")
            print(f"✅ Converted {label} -> {class_id}: {x_center}, {y_center}, {bbox_width}, {bbox_height}")

print("🎯 Conversion complete! Dataset is ready for training.")
