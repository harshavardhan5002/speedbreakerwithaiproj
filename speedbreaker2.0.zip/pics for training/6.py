import os
import json
import glob

# Path to your LabelMe JSON files
labelme_folder = r"C:\Users\harsh\OneDrive\Desktop\pics for training"

# Check each JSON file
json_files = glob.glob(os.path.join(labelme_folder, "*.json"))

for json_file in json_files:
    with open(json_file, "r") as f:
        data = json.load(f)
    
    print(f"📂 File: {json_file}")
    if "shapes" in data and len(data["shapes"]) > 0:
        for shape in data["shapes"]:
            print(f"  🏷 Label: {shape['label']}, Points: {shape['points']}")
    else:
        print("  ❌ No annotations found!")

print("✅ JSON check completed!")
