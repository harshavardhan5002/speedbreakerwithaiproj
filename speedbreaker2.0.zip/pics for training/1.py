import os
import json
import xml.etree.ElementTree as ET
from glob import glob

# Input: Folder where JSON files are stored
json_dir = "C:/Users/harsh/OneDrive/Desktop/pics for training"
xml_output_dir = "C:/Users/harsh/OneDrive/Desktop/pics for training"

if not os.path.exists(xml_output_dir):
    os.makedirs(xml_output_dir)

for json_file in glob(os.path.join(json_dir, "*.json")):
    with open(json_file, 'r') as f:
        data = json.load(f)

    image_name = data["imagePath"]
    width = data["imageWidth"]
    height = data["imageHeight"]

    annotation = ET.Element("annotation")
    ET.SubElement(annotation, "filename").text = image_name
    size = ET.SubElement(annotation, "size")
    ET.SubElement(size, "width").text = str(width)
    ET.SubElement(size, "height").text = str(height)
    ET.SubElement(size, "depth").text = "3"

    for shape in data["shapes"]:
        obj = ET.SubElement(annotation, "object")
        ET.SubElement(obj, "name").text = shape["label"]
        bndbox = ET.SubElement(obj, "bndbox")
        x1, y1 = shape["points"][0]
        x2, y2 = shape["points"][1]
        ET.SubElement(bndbox, "xmin").text = str(int(x1))
        ET.SubElement(bndbox, "ymin").text = str(int(y1))
        ET.SubElement(bndbox, "xmax").text = str(int(x2))
        ET.SubElement(bndbox, "ymax").text = str(int(y2))

    tree = ET.ElementTree(annotation)
    tree.write(os.path.join(xml_output_dir, os.path.basename(json_file).replace(".json", ".xml")))

print("✅ Converted all JSON files to Pascal VOC XML format.")
