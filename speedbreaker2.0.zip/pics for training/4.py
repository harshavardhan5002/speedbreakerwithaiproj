from labelme2yolo import convert

# Change this path to your dataset folder
convert("C:/Users/harsh/OneDrive/Desktop/pics for training")
