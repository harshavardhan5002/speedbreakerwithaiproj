from ultralytics import YOLO
import cv2
import threading
import time

# Load YOLO model
model = YOLO("C:/Users/harsh/runs/detect/train2/weights/best.pt")  # Change path if needed

# Open webcam (0 = default camera, 1 = external)
cap = cv2.VideoCapture(0)

# ✅ Increase FPS by setting camera properties
cap.set(cv2.CAP_PROP_FPS, 30)  # Request higher FPS (try 60 if supported)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)  # Reduce resolution for higher FPS
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

# Global variables for threaded video capture
ret, frame = cap.read()  # ✅ Initialize ret and frame

# ✅ Threaded video capture function
def grab_frame():
    global ret, frame
    while cap.isOpened():
        ret, frame = cap.read()

# ✅ Start video capture thread
thread = threading.Thread(target=grab_frame, daemon=True)
thread.start()

# ✅ FPS Measurement
fps_time = time.time()

while cap.isOpened():
    if not ret:
        print("❌ Failed to grab frame.")
        break

    # ✅ Run YOLO detection (lower confidence & smaller iou speeds it up)
    results = model.predict(frame, conf=0.4, iou=0.5, show=True, stream_buffer=True)

    # ✅ Calculate FPS
    fps = 1 / (time.time() - fps_time)
    fps_time = time.time()
    print(f"🔥 FPS: {fps:.2f}")  # Display FPS in terminal

    # ✅ Press 'q' to exit
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
