import urllib.request
import tarfile

# URL of the pre-trained model
MODEL_URL = "http://download.tensorflow.org/models/object_detection/ssd_mobilenet_v2_fpnlite_320x320_coco17_tpu-8.tar.gz"
MODEL_PATH = "ssd_model.tar.gz"
EXTRACT_DIR = "ssd_mobilenet_v2"

# Download the model
print("🚀 Downloading pre-trained model...")
urllib.request.urlretrieve(MODEL_URL, MODEL_PATH)
print("✅ Download complete!")

# Extract it
print("📂 Extracting model files...")
with tarfile.open(MODEL_PATH, "r:gz") as tar:
    tar.extractall(path=EXTRACT_DIR)
print("✅ Model extracted successfully!")
