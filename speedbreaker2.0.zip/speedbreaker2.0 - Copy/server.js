const { SerialPort } = require("serialport");
const { ReadlineParser } = require("@serialport/parser-readline");
const express = require("express");
const http = require("http");
const socketIo = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.static("public")); // Serve frontend files

// 🎯 MANUALLY SET ARDUINO COM PORT
const portName = "COM11";  // Change if needed

// 🚀 Track detections
let arduinoDetection = false;
let yoloDetection = false;
let lastEvent = "Normal";
let lastLat = null, lastLon = null;  // Store last location

// 🚀 Start Serial Communication with Arduino
const serialPort = new SerialPort({ path: portName, baudRate: 9600 });
const parser = serialPort.pipe(new ReadlineParser({ delimiter: "\n" }));

serialPort.on("open", () => {
    console.log(`✅ Connected to Arduino on ${portName}`);
});

parser.on("data", (line) => {
    console.log("📡 Received from Arduino:", line.trim());

    try {
        const sensorData = JSON.parse(line.trim());

        // 🔄 Update detection status
        arduinoDetection = sensorData.event.includes("Bump") || sensorData.event.includes("Pothole");

        // 🔥 If both YOLO & Arduino detect, send a marker
        checkAndSendDetection(sensorData);

        io.emit("sensorData", sensorData);
    } catch (error) {
        console.error("⚠️ Error parsing serial data:", error.message);
    }
});

serialPort.on("error", (err) => {
    console.error("⚠️ Serial Port Error:", err.message);
});

// 🎯 Handle WebSocket Connections
io.on("connection", (socket) => {
    console.log("✅ Client Connected");

    socket.on("yolo_detection", (data) => {
        console.log("📡 YOLO Detection Received:", data);

        // 🔄 Update YOLO detection status
        yoloDetection = data.detected;

        // 🔥 If both YOLO & Arduino detect, send a marker
        checkAndSendDetection(data);
    });

    socket.on("disconnect", () => console.log("❌ Client Disconnected"));
});

// 🔥 Function to Validate and Send Detection
function checkAndSendDetection(data) {
    if (arduinoDetection && yoloDetection) {
        console.log("📌 Confirmed Detection from both YOLO & Arduino!");

        // ✅ Get current location and add marker
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((pos) => {
                lastLat = pos.coords.latitude;
                lastLon = pos.coords.longitude;
                io.emit("final_detection", {
                    type: data.event || "Speed Bump",
                    status: "Confirmed",
                    lat: lastLat,
                    lon: lastLon
                });
            }, (err) => {
                console.warn("⚠️ Geolocation error:", err);
            });
        }
    } else if (arduinoDetection || yoloDetection) {
        console.log("⚠️ Partial Detection: Only one system detected!");
        io.emit("final_detection", { type: data.event || "Unknown", status: "Partial" });
    } else {
        io.emit("final_detection", { type: "Normal Road", status: "Normal" });
    }
}

// 🚀 Start Server
server.listen(3000, () => {
    console.log("🚀 Server is running on http://localhost:3000");
});
