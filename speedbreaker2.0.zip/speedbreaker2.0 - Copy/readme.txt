1. Install Node.js
2. node server.js in cmd of that directory

